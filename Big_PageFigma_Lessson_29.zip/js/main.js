
var content = [];

function NewPage() {
    document.getElementById('newpage').value = content
}